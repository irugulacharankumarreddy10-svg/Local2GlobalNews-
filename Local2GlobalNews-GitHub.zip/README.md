# Local2Global News

Local news with global reach.

This is a starter web version of the Local2Global News app.
